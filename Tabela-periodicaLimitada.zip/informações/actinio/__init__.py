def informacoes_actinio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Actínio é 89')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O actínio faz parte da série dos actinídeos,
que é um grupo de elementos que pertencem à família dos actinídeos.
''')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Actínio é aproximadamente 227 u.')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O actínio é um elemento metálico altamente radioativo, prateado e brilhante.
Devido à sua radioatividade, é difícil de estudar em detalhes e não tem muitas 
aplicações práticas.
''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s² 
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹⁰ 4f¹⁴
5s² 5p⁶ 5d¹⁰ 5f¹
6s² 6p⁶
7s²
''')
    return informacoes
    
  elif  pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O nome "actínio" deriva da palavra grega "aktinos", que significa "raio" ou "radiação".
Esse nome foi escolhido devido à intensa radiação que o elemento emite. 
''')
    return informacoes
    
  elif pesquisa == 'periodo'or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O actínio está localizado no sétimo período da tabela periódica.
Isso significa que ele possui 7 níveis de energia na sua 
configuração eletrônica.
''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes