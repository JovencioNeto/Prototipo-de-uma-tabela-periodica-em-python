def informacoes_aluminio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do alumínio é 13.')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
  Trata-se de um elemento de característica metálica (metal) e está localizado
  no terceiro período da família do Boro (família IIIA), na Tabela Periódica, sendo,
  portanto, um elemento representativo.
  ''')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('O elemento possui 26,981539 u de massa.')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O alumínio é um elemento metálico muito abundante na crosta terrestre e suas
características de resistência, leveza e condutividade elétrica fazem com que
seja amplamente utilizado na engenharia aeronáutica, na construção de navios,
pontes, automóveis, etc.
''') 
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶
3s² 3p¹
''')  
    return informacoes
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O alumínio foi descoberto em 1825, em Copenhaga, Dinamarca, pelo físico dinamarquês Hans
Christian Oersted (1777-1851) e na Alemanha pelo químico Friedrich Woehler (1800-1882).
O nome alumínio deriva do latim alumen que significa alúmen.
''')    
    return informacoes
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O alumínio localiza-se no grupo 13 e período 3 da Tabela Periódica.
Isso signiica que ele possui 3 níveis de energia na sua configuração
eletrônica.''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes