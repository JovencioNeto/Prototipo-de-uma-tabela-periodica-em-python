def informacoes_americio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Amerício é 95.')
    return informacoes

  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O amerício, símbolo Am, é um metal pertencente ao grupo dos actinídeos.
  ''')
    return informacoes

  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Amerício é aproximadamente 243 u.')
    return informacoes

  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
amerício (nome dado em homenagem ao Continente Americano) é um elemento químico
radioativo e transurânico com símbolo Am e número atômico 95. É um elemento actínio,
localizado na tabela periódica abaixo do elemento európio, um lantanídio, e portanto
por analogia, foi nomeado a partir de outro continente, a América.[1]
  ''')
    return informacoes

  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
  1s² 
  2s² 2p⁶ 
  3s² 3p⁶ 3d¹⁰
  4s² 4p⁶ 4d¹⁰ 4f¹⁴
  5s² 5p⁶ 5d¹⁰ 5f⁷
  6s² 6p⁶
  7s²
  ''')
    return informacoes

  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
Latim científico americium, de América, topônimo.
  ''')
    return informacoes

  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
  O amerício, cujo símbolo químico é Am, é um elemento químico sólido, metálico,
  preparado por síntese, radioativo, pertencente ao grupo dos actinídeos,
  de cor prateada, que se localiza no grupo 3 e período 7 da Tabela Periódica. 
  ''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes

