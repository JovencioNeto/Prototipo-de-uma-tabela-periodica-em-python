def informacoes_antimonio(pesquisa):
  
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Antimônio é 51')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O antimônio está localizado no grupo 15 da tabela periódica,
que é conhecido como o grupo do "nitrogênio" ou "azoto".
''')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Antimônio é aproximadamente 121.76 u.')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O antimônio é um elemento metaloide, o que significa que ele tem propriedades 
intermediárias entre os metais e os não-metais. Ele é frequentemente encontrado
na forma de minerais como estibina (antimônio estibinita) e é usado em várias aplicações
, incluindo ligasmetálicas e semicondutores.
''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹⁰
5s² 5p³
''')
    return informacoes
    
  elif  pesquisa == 'origem do nome':
    informacoes = ('''
O nome "antimônio" deriva do grego "anti" (contra) e "monos" (solitário) 
devido à sua natureza não metálica. O elemento era conhecido desde a antiguidade
e foi usado em várias aplicações, incluindo medicina e pigmentos. 
''')
    return informacoes
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O antimônio está localizado no período 5 da tabela periódica, 
o que significa que ele tem 5 níveis de energia em sua 
configuração eletrônica.
''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes