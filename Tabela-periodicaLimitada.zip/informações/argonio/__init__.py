def informacoes_argonio(pesquisa):
  
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Argonio é 18.')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Argônio é um elemento químico pertencente a família 
dos gases nobres.
''')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('O Argonio possui 39,948 u de massa.')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O argônio é o mais abundante membro da família dos gases nobres. Esse gás é monoatômico
e caracterizado por sua extrema inatividade química. O argônio é incolor, inodoro, não
inflamável, não tóxico, insípido e ligeiramente solúvel em água.
''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶
3s² 3p⁶
''')
    return informacoes
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
Entretanto, esse novo elemento só recebeu nome em 1894, pelos ingleses William Ramsay e
Lord Rayleigh. Eles isolaram o gás por meio da destilação do ar líquido, e devido a sua
inércia e a densidade maior que a do nitrogênio, recebeu o nome de argônio, que 
significa preguiçoso, do grego argos.
''')
    return informacoes
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O argônio, símbolo Ar, é um gás nobre do 3° período da Tabela Periódica.
Isso significa que ele possui 3 níveis de energia na sua configuração eletrônica.
''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes