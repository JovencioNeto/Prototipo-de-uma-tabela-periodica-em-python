def informacoes_astato(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Ástato é 85.')
    return informacoes

  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Ástato (At), também designado por estantino, é um elemento químico
semi-metálico radioativo, pertencente ao grupo dos halogéneos, que se
localiza no grupo 17 e período 6 da Tabela Periódica.
  ''')
    return informacoes

  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Ástato é aproximadamente  210 u.')
    return informacoes

  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Ástato é altamente radioativo comporta-se quimicamente como os demais halogênios,
especialmente como o iodo. O ástato tem caráter mais metálico que o iodo.
Pesquisadores do Laboratório Nacional de Brookhaven identificaram as
reações e as medidas elementares que envolvem o ástato. A maioria
das características do ástato são conhecidos através dos seus
isótopos sintéticos.
  ''')
    return informacoes

  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹⁰ 4f¹⁴
5s² 5p⁶ 5d¹⁰
6s² 6p⁵
  ''')
    return informacoes

  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O nome Ástato deriva do grego astatos que significa instável.
É relativamente desconhecido devido à sua curta semivida.
  ''')
    return informacoes

  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Ástato (At), também designado por estantino, é um elemento químico 
semi-metálico radioativo, pertencente ao grupo dos halogéneos, que se
localiza no grupo 17 e período 6 da Tabela Periódica.
  ''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes

