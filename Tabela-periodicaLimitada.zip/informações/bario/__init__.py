def informacoes_bario(pesquisa):
  if  pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Bário é 56')
    return informacoes 
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('O Bário pertence à família dos metais alcalino-terrosos.')
    return informacoes 
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Bário é aproximadamente 137,327 u.')
    return informacoes 
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = (''' 
O Bário é um metal alcalino-terroso de cor prateada e é altamente reativo com a água e
o oxigênio. É usado em diversas aplicações, incluindo na indústria de vidro e na
medicina, onde os compostos de bário são usados como agentes de contraste em exames
de raios-X.  
''')
    return informacoes 
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = (''' 
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹⁰
5s² 5p⁶ 
6s²
''')
    return informacoes 
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
A palavra "Bário" tem sua origem no grego antigo. Ela deriva do termo grego "barys",
que significa "pesado". O nome "Bário" foi escolhido devido à densidade relativamente
alta desse elemento em comparação com outros elementos alcalino-terrosos. 
''')
    return informacoes 
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
Localizado no 6° período da tabela periódica. Isso significa que ele
possui 6 níveis de energia na sua configuração eletrônica.
''')
    return informacoes 

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes