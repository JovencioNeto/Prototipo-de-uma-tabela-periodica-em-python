def informacoes_berilio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Berílio é 4.')
    return informacoes 
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('O metal alcalino terroso berílio é um elemento químico pertencente a família 2A.')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('O Berílio possui 9,012182 u de massa.')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O berílio puro é um metal duro acinzentado, o mais leve de todos os metais,
encontrado em rochas minerais, carvão, solo e poeira vulcânica. A maior parte
do berílio extraído é convertida em ligas usadas na fabricação de peças elétricas
e eletrônicas ou como materiais de construção para máquinas e moldes para plásticos.
  ''')
    return informacoes
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s²
''')
    return informacoes
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
Foi descoberto em 1797 pelo químico francês Louis-Nicolas Vauquelin (1763-1829)
e foi isolado pela primeira vez pelo químico alemão Friederich Woehler (1800-1882) 
e pelo cientista A. Bussy em 1828. O nome berílio deriva do grego beryllos
que é o nome da uma pedra preciosa.
''')
    return informacoes
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O elemento localiza-se no grupo 2 e período 2 da Tabela Periódica.
Isso significa que ele possui 2 camadas de energia na sua configuração eletrônica.
''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes