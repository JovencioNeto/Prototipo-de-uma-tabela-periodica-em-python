def informacoes_bismuto(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Bismuto é 83.')
    return informacoes

  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Bismuto pertence à família dos semimetais ou metaloides, e está localizado no grupo 15
da tabela periódica dos elementos. O grupo 15 também é conhecido como grupo do 
nitrogênio ou pnictogênio e inclui elementos como nitrogênio (N), fósforo (P),
arsênio (As), antimônio (Sb) e bismuto (Bi).
  ''')
    return informacoes

  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Bismuto é aproximadamente 208.98 u.')
    return informacoes

  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Bismuto é pesado, frágil, trivalente, cristalino, de coloração rosácea que se 
assemelha quimicamente ao arsênio e ao antimônio. É o mais diamagnético de todos
os metais, e com a condutividade térmica mais baixa entre todos os elementos, exceto
do mercúrio. De todos os metais, é o que menos conduz corrente elétrica.
  ''')
    return informacoes

  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹⁰ 4f¹⁴
5s² 5p⁶ 5d¹⁰
6s² 6p³
  ''')
    return informacoes

  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O nome "bismuto" tem origem no alemão. O termo deriva da palavra alemã "Wismuth" ou 
"Weisse Masse", que significa "massa branca". Essa denominação está relacionada à 
cor característica do bismuto, que é um metal branco ou prateado com um brilho rosado.
O bismuto é um elemento químico pertencente ao grupo dos semimetais ou metaloides,
e tem o símbolo químico Bi com o número atômico 83. Sua designação está vinculada 
à sua aparência física distintiva e foi assim nomeado pelos químicos alemães em meados
do século XV.
  ''')
    return informacoes

  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Bismuto está localizado no 6º período da tabela periódica dos elementos. 
Isso significa que o bismuto tem 6 níveis de energia ou camadas eletrônicas
ao redor do núcleo atômico.
  ''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes

