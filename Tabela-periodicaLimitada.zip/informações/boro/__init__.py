def informacoes_boro(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico deste elemento é 5.')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O boro é um semimetal que pertence à família 3A ou grupo 13,
com cinco prótons em sua estrutura.
''')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('O Boro possui 10.811 u de massa.')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Boro é um ametal de coloração preto lustrosa, constitui cerca de 0,001% da crosta
terrestre e é principalmente extraído do bórax e da kernita.
''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p¹
''')
    return informacoes
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
Nome dado devido a um dos seus sais, bórax, tetraborato de sódio, Na2B4O7.
A descoberta do boro em 1808 é atribuída a Joseph-Louis Gay-Lussac e a 
Louis Jacques Thénard.
Foi obtido pela reação do potássio com o óxido de boro, a quente, isto é, K + B2O3.
''')
    return informacoes
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Boro localiza-se no grupo 13 e período 2 da Tabela Periódica.
Isso significa que ele possui 2 níveis de energia na sua 
configuração eletrônica.
''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes