def informacoes_cadmio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Cádmio é 48.')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O cádmio pertence ao grupo 12 da tabela periódica, 
que também é conhecido como o grupo dos "metais de transição".
''')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Cádmio é aproximadamente 112.41 u.')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O cádmio é um metal de cor branca prateada, semelhante ao aspecto do mercúrio.
É um elemento relativamente raro na crosta terrestre, mas é usado em várias a
plicações industriais, incluindo baterias recarregáveis, pigmentos, 
revestimentos anticorrosivos e em alguns tipos de solda. 
''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹⁰
5s²
''')
    return informacoes
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O nome "cádmio" tem origem na mitologia grega. O cádmio foi descoberto em 1817 por 
Friedrich Stromeyer e recebeu esse nome em referência à palavra grega "kadmeia",
que era um termo usado para designar minerais de zinco. 
''')
    return informacoes
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Cádmio está localizado no período 5 da tabela periódica,
o que significa que ele tem 5 níveis de energia em sua 
configuração eletrônica.
''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes