def informacoes_calcio(pesquisa):
  
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Cálcio é 20. ')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('O Cálcio pertence à família dos metais alcalino-terrosos.')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Cálcio é aproximadamente 40,078 u .')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = (''' 
O cálcio é um metal alcalino-terroso de cor prateada, essencial para a vida. Encontrado
abundantemente na natureza, é crucial para funções biológicas, incluindo contração
muscular, transmissão de impulsos nervosos e coagulação sanguínea.
''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 
4s²
''')
    return informacoes
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
A palavra "cálcio" tem sua origem no termo latino "calx", que significa "cal" ou
"cal viva". A associação com a cal se deve ao fato de que o cálcio é frequentemente
encontrado na forma de minerais de carbonato de cálcio, como a calcita e a dolomita,
que são usados na produção de cal e cal viva. 
''')
    return informacoes
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
Localizado no 4° período da tabela periódica. Isso significa que ele
possui 4 camadas de energia na sua configuração eletrônica.
''')
    return informacoes
    
  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes