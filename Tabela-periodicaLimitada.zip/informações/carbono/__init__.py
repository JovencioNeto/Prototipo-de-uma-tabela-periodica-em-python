def informacoes_carbono(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or  pesquisa == 'número atomico' or pesquisa == 'numero atômico' or  pesquisa == '1':
    informacoes =('O número atômico deste elemento é 6')
    return informacoes 
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes =('O carbono é um não metal do grupo 14 ou família 4A, segundo período.')
    return informacoes 
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes =('O elemento possui 12,011 u de massa.')
    return informacoes 
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes =('''
O carbono é um elemento químico famoso por ser uma das principais
causas das mudanças no clima, apesar de ser também um elemento-chave para a vida 
na Terra.
Apresentado como o sexto átomo da tabela periódica e base de uma variedade de 
moléculas que compõem a química orgânica.
''')
    return informacoes 
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes =('''
1s²
2s² 2p²
''')
    return informacoes 
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes =('''
O nome do carbono em inglês deriva de Carbon,
que vem do latim Carbo, que significa carvão em brasa.
''')
    return informacoes 
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes =('''
O carbono (C) é um elemento químico não metálico que
se localiza no grupo 14 e período 2 da Tabela Periódica.
Isso significa que ele possui 2 níveis de energia na sua 
configuração eletrônica.
''')
    return informacoes 

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes
