def informacoes_chumbo(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Chumbo é 82.')
    return informacoes

  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Chumbo pertence à família dos metais representativos e está localizado no grupo 14
da tabela periódica dos elementos. O grupo 14 também é conhecido como grupo do carbono
e inclui elementos como carbono (C), silício (Si), germânio (Ge), estanho (Sn) e
chumbo (Pb). 
  ''')
    return informacoes

  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Chumbo é aproximadamente 207.2 u.')
    return informacoes

  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Chumbo é um metal tóxico, denso, macio, maleável e mau condutor de eletricidade.
Apresenta coloração branco-azulada quando recentemente cortado, porém adquire 
coloração acinzentada quando exposto ao ar. É usado na construção civil, baterias de 
ácido, em munição, proteção contra raios-X e raios gamma e forma parte de ligas metálicas
para a produção de soldas, fusíveis, revestimentos de cabos elétricos, materiais 
antifricção, metais de tipografia, etc. O Chumbo tem o número atômico mais elevado entre
todos os elementos estáveis.
  ''')
    return informacoes

  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹⁰ 4f¹⁴
5s² 5p⁶ 5d¹⁰
6s² 6p²
  ''')
    return informacoes

  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O nome "chumbo" tem origens na língua latina. A palavra latina para chumbo é "plumbum".
O símbolo químico do chumbo na tabela periódica é Pb, derivado da palavra latina 
"plumbum". Essa origem está relacionada à antiguidade, quando o chumbo era 
frequentemente associado a prata. O termo "plumbum" também está na raiz de
palavras em várias línguas modernas, como "plomb" em francês e "plomo" em 
espanhol, ambas significando chumbo. O uso da palavra "chumbo" para se 
referir a esse elemento tem sido consistente através dos tempos, 
refletindo sua história e importância em diversas aplicações, 
incluindo a produção de canos e outras utilidades.
  ''')
    return informacoes

  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Chumbo está localizado no 6º período da tabela periódica dos elementos.
Isso significa que o chumbo tem 6 níveis de energia ou camadas eletrônicas 
ao redor do núcleo atômico. 
  ''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes

