def informacoes_cloro(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do cloro é 17.')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Cloro (Cl) pertence ao grupo 17 da Tabela Periódica,
conhecido como família dos halogênios.
  ''')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('O Cloro possui 35,453 u de massa.')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
Em temperatura ambiente e pressão atmosférica, o cloro é um gás de coloração
amarelo-esverdeada que se torna líquido ao ser resfriado até a temperatura de -34 °C.
''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶
3s² 3p⁵
''')
    return informacoes
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('O nome Cloro deriva do grego chloros que significa verde-pálido.')
    return informacoes
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Cloro pertence ao grupo 17 ou família 7A, 3° período, série dos halogênios
Isso significa que ele possui 3 camadas de energia na sua 
configuração eletrônica.''')
    return informacoes
    
  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes