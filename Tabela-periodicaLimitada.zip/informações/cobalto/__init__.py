def informacoes_cobalto(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Cobalto é 27.')
    return informacoes

  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
  O Cobalto pertence à família dos metais de transição, 
  especificamente ao grupo 9 da tabela periódica.
    ''')
    return informacoes

  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Cobalto é aproximadamente  58,93.')
    return informacoes

  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Cobalto é um metal de cor prateada que é sólido à temperatura ambiente. É 
frequentemente usado em ligas metálicas e é conhecido por sua resistência à corrosão. 
''')
    return informacoes

  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d⁷ 
4s²
''')
    return informacoes

  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O nome "Cobalto" deriva da palavra alemã "kobalt" ou "kobold", que significa "duende" 
ou "espírito maligno".Isso se deve ao fato de que os mineiros medievais encontraram
minerais de Cobalto que emitiam gases nocivos quando aquecidos,causando doenças e 
morte, o que eles atribuíam a seres sobrenaturais. O nome reflete a dificuldade 
que eles tinham em trabalhar com o Cobalto devido à sua toxicidade. 
''')
    return informacoes

  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = (''' 
O Cobalto está localizado no 4º período da tabela periódica, 
o que significa que está na 4º linha horizontal da tabela.
''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes