def informacoes_cobre(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Cobre é 29.')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = (''' 
O Cobre está localizado no grupo 11 da tabela periódica,
também conhecido como o grupo dos metais de transição.
''')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Cobre é aproximadamente 63,55 u .')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Cobre é um metal de cor avermelhada e é conhecido por sua excelente 
condutividade elétrica e térmica. É frequentemente utilizado em 
fios elétricos, encanamentos, moedas e em muitas aplicações industriais
devido a essas propriedades. 
''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d⁹
4s²
''')
    return informacoes
  
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O nome "Cobre" deriva do latim "cuprum". A origem deste nome está associada 
à ilha de Chipre, onde o Cobre era minerado na antiguidade. 
''')
    return informacoes
  
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Cobre está localizado no 4º período da tabela periódica, o que significa que ele
tem 4 níveis de energia na sua configuração eletrônica.
''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes