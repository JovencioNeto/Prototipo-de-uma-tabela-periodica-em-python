def informacoes_criptonio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Criptônio é 36')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Criptônio está localizado no grupo 18 da tabela periódica, 
que é conhecido como o grupo dos "gases nobres" ou "gases inertes". 
''')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Criptônio é aproximadamente 83.798 u.')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Criptônio é um gás nobre incolor, inodoro e insípido. Ele é encontrado na 
atmosfera em quantidades muito pequenas. 
O nome "criptônio" deriva do termo grego "kryptos",
que significa "oculto", devido à sua natureza pouco reativa. 
''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 
''')
    return informacoes
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O nome "Criptônio" foi derivado do termo grego "kryptos," 
que significa "oculto" ou "escondido," devido à sua natureza 
pouco reativa e ao fato de ter sido descoberto em traços na 
atmosfera antes de ser isolado em laboratório. 
''')
    return informacoes
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Criptônio está localizado no 4º período da tabela periódica, o que significa
que ele tem 4 níveis de energia em sua configuração eletrônica.
''')
    return informacoes
    
  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes