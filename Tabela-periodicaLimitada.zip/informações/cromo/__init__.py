def informacoes_cromo(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes =('O número atômico do Crômio é 24.')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes =('''
O Crômio pertence aos Metais, Metais de transição, Metais pesados tóxicos,
Elementos do 4º período, Elementos do 6º Grupo.
''')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes =('A massa do Crômio é aproximadamente 51,9961 u.')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes =('''
O Crômio é um metal acinzentado muito resistente à corrosão.
Possui diferentes estados de oxidação e os mais comuns são crômio (II), (III) e (VI),
também denominados bi, tri e hexavalente, respectivamente.
''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes =('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d⁴
4s²
''')
    return informacoes
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes =('''
O nome Crômio tem origem na palavra grega “chroma”, que significa cor. 
O elemento foi chamado assim por causa da variedade de coloração 
encontrada nos compostos de cromo. Por volta de 1800, o químico 
alemão Tassaert trabalhando em Paris encontrou cromo em um novo minério, 
chamado cromita.
''')
    return informacoes
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes =('''
O Crômio localiza-se no grupo 6 e período 4 da Tabela Periódica.
Isso significa que ele possui 4 níveis de energia na sua configuração eletrônica.
''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes