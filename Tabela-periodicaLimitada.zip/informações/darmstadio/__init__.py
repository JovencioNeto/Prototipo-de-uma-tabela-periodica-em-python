def informacoes_darmstadio(pesquisa):
  