def informacoes_disprosio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Disprósio é 66.')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Disprósio é um metal de transição interna pertencente a família dos lantanídeos,
é branco prateado maleável extremamente mole podendo ser facilmente cortado com uma faca
pelo simples ato de pressioná-la sobre o metal.
''')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Disprósio é aproximadamente  162,5u.')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Disprósio é um elemento químico metálico de símbolo Dy e número atômico 66.
Ele faz parte do grupo das terras raras e é relativamente estável no ar em
temperatura ambiente, porém se dissolve em ácidos minerais diluídos ou
concentrados com liberação de hidrogênio, isto é, oxidando-se.
''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹⁰ 4f¹⁰
5s² 5p⁶
6s² 
''')
    return informacoes
    
  elif  pesquisa == 'origem do nome' or pesquisa == '7':
    informacoes = ('''
O elemento em si não foi isolado em forma relativamente pura.
Ocorreu somente depois do desenvolvimento das técnicas de troca iônica e
redução metalográfica nos anos 50.
''')
    return informacoes
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Disprósio está localizado no 6º período da tabela periódica.
Isso significa que ele possui 6 níveis de energia na sua configuração 
eletrônica.
''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes