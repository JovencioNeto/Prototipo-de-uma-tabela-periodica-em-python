def informacoes_dubnium(pesquisa):
