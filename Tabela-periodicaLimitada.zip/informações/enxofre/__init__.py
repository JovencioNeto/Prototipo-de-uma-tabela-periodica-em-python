def informacoes_enxofre(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do enxofre é 16.')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O elemento enxofre está posicionado na Tabela Periódica no terceiro período (coluna horizontal) do grupo 16 (conhecido como família VIA ou família dos calcogênios)
''')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('O Enxofre possui 32,065 u de massa.')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O enxofre é um sólido amarelo classificado na tabela periódica como um não metal e representa cerca de 3% da massa terrestre. É base para a síntese de ácido sulfúrico, um dos compostos mais produzidos mundialmente em escala industrial. O enxofre também
está presente na constituição dos aminoácidos de plantas e animais.
''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶
3s² 3p⁴
''')
    return informacoes
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O termo enxofre deriva da palavra latina sulphur. Essa substância é conhecida desde a
História Antiga, contudo, somente no ano de 1777, foi reconhecido como um elemento 
químico por Antoine Lavoisier.
''')
    return informacoes
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O enxofre está localizado no terceiro período (coluna horizontal)
do grupo 16 (conhecido como família VIA ou família dos calcogênios).
Isso significa que ele possui 3 níveis de energia na sua configuração 
eletrônica.
''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes