def informacoes_erbio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Érbio é 68.')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Érbio é um elemento químico que pertence à família dos lantanídeos,
também conhecida como a família dos lantanoides ou terras raras.
''')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Èrbio é aproximadamente 167.259 u.')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Érbio é utilizado na metalurgia além de ter usos em usinas
nucleares pra absorção de nêutrons em reatores nucleares.
O óxido de Érbio é utilizado na coloração de vidros e
esmaltes para porcelanato e cerâmicas.
''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹⁰ 4f¹²
5s² 5p⁶
6s² 
''')
    return informacoes
    
  elif  pesquisa == 'origem do nome' or pesquisa == '7':
    informacoes = ('''
O nome "Érbio" deriva do latim "Erbium", que foi nomeado em homenagem
ao químico sueco Carl Gustaf Mosander.
Carl Mosander foi um químico notável do século XIX que fez contribuições 
significativas para o estudo dos lantanídeos, uma série de elementos químicos 
que inclui o Érbio.
''')
    return informacoes
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Érbio está localizado no 6º período da tabela periódica.
Isso significa que ele possui 6 níveis de energia em 
sua configuração eletrônica. 
''')
    return informacoes
    
  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes