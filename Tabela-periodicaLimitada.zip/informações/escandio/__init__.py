def informacoes_escandio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Escândio é 21.')
    return informacoes 

  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Escândio pertence  aos Metais, Metais de transição, Terra-rara,
Metais pesados tóxicos, Elementos do Grupo 3, Elementos do 4º período.
''')
    return informacoes 

  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Escandio é aproximadamente 44,955912 u.')
    return informacoes 

  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Escândio é usado em aplicações especiais, como a composição de tacos de beisebol,
quadros de bicicleta, aviões de guerra e lâmpadas de mercúrio.
O Escândio pode ser obtido de minerais como a thortveitita ou como subproduto 
da extração do urânio.
''')
    return informacoes 

  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = (''' 
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d¹
4s²
''')
    return informacoes 

  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O nome Escândio deriva do latim Scandia que significa Escandinávia. 
O Escândio ocorre nos minérios dos lantanóides (terras raras) 
dos quais pode ser separado tendo em conta a grande solubilidade 
do seu tiocianato em éter.
''')
    return informacoes 

  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Escândio  localiza-se no grupo 3 e período 4 da Tabela Periódica.
Isso significa que ele possui 4 níveis de energia na sua configuração eletrônica.
''')
    return informacoes 

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes