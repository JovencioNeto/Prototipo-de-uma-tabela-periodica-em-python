def informacoes_europio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Európio é 63')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Európio faz parte da família dos lantanídeos,
que é uma das famílias na tabela periódica.''')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Európio é aproximadamente 152,0 u.')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Európio é um metal de transição interna prateado
branco que é relativamente macio e maleável.
Ele é reativo ao ar e oxida-se facilmente. 
''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹⁰ 4f⁷
5s² 5p⁶
6s² 
''')
    return informacoes
    
  elif  pesquisa == 'origem do nome' or pesquisa == '7':
    informacoes = ('''
O nome "Európio" vem da Europa,
o continente onde foi descoberto.
Foi isolado pela primeira vez por
Eugène-Anatole Demarçay em 1901. 
''')
    return informacoes
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Európio está localizado no 6° período da tabela periódica,
o que significa que possui 6 níveis de energia em sua 
configuração eletrônica.
''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes