def informacoes_ferro(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do  é 26.')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Ferro pertence à família 8 da tabela periódica, conhecida como a família do Ferro.
Também é chamada de família do grupo 8 ou família do níquel.
''')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Ferro é aproximadamente 55,85 u.')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Ferro é um metal de transição de cor prateada, que
oxida acilmente para formar a ferrugem quando exposto à umidade
do ar. 
''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶  
3s² 3p⁶  3d⁶
4s² 
''')
    return informacoes
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
A palavra "Ferro" vem do latim "ferrum". O símbolo "Fe" também tem origem no latim.
O Ferro é um dos elementos mais antigos conhecidos pela humanidade e tem sido usado
desde a antiguidade. 
''')
    return informacoes
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Ferro está localizado no período 4 da tabela periódica, o que significa 
que ele possui quatro níveis de energia ocupados por elétrons em sua 
configuração eletrônica.
''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes
