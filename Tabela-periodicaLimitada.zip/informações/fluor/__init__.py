def informacoes_fluor(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes =('O número atômico deste elemento é 9.')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes =('''
O Flúor pertence ao grupo dos halogéneos, monovalente, de cor amarelo-esverdeada e
cheiro penetrante, que se localiza no grupo 17 e período 2 da Tabela Periódica.
''')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes =('O Flúor possui 18,998403 u de massa.')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes =('''
O Flúor é o mais eletronegativo e reativo de todos os elementos químicos, contudo é
encontrado na natureza somente na sua forma iônica, fluoreto, combinado a metais ou
ao hidrogênio. O fluoreto de hidrogênio é um gás ou líquido incolor com odor pungente
e altamente solúvel em água onde forma ácido hidrofluorídrico.
''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes =('''
1s²
2s² 2p⁵
''')
    return informacoes
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes =('O nome Flúor deriva do latim fluere que significa fluir.')
    return informacoes
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes =('''
O Flúor é localizado no grupo 17 e período 2 da Tabela Periódica.
Isso significa que ele possui 2 níveis de eneria na sua configuração eletrônica.
''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes