def informacoes_fosforo(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do fósforo é 15.')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Fósforo é um ametal(elemento químico não metálico) pertencente à família 
15 ou 5ª da tabela periódica.
''')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('O Fósforo possui 30,973762 u de massa.')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
Em temperatura ambiente, é incolor e semitransparente, mas no escuro apresenta
fosforescência (brilha). É macio, possuindo aparência de cera de abelha. Além disso,
o fósforo é altamente reativo quando exposto à atmosfera.
''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶
3s² 3p³
''')
    return informacoes
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O termo fósforo tem origem no latim phosphorus, que por sua vez deriva do grego 
phosphoros, uma junção de phos (luz) mais phoros (portador).
  ''')
    return informacoes
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Fósforo localiza-se no grupo 15 e período 3 da Tabela Periódica.
Isso significa que ele posui 3 níveis de energia na sua configuração eletrônica.
''')
    return informacoes
    
  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes