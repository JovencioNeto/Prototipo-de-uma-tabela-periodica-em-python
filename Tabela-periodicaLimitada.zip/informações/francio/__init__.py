def informacoes_francio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Frâncio (Fr) é 87.')
    return informacoes 
    
  elif pesquisa == 'Família' or pesquisa == 'familia' or pesquisa == '2' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Frâncio pertence à família dos metais alcalinos na tabela periódica 
dos elementos. 
''')
    return informacoes 
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('''
O Frâncio (Fr) é um elemento químico altamente radioativo e instável,
e sua massa pode variar devido à existência de isótopos com 
diferentes números de nêutrons. No entanto, sua massa média é cerca de 223 u .
''')
    return informacoes 
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Frâncio é um elemento químico altamente radioativo com número atômico 87.
É extremamente raro na natureza e é produzido como subproduto da degradação
de outros elementos radioativos, como o urânio.
''')
    return informacoes 
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰ 
4s² 4p⁶ 4d¹⁰ 4f¹⁴
5s² 5p⁶ 5d¹⁰
6s² 6p⁶ 
7s¹
''')
    return informacoes 
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O nome "Frâncio" é o nome oficial do elemento químico com o símbolo "Fr".
O nome foi escolhido em homenagem à França, o país de origem da cientista
que o descobriu, Marguerite Perey, em 1939.
''')
    return informacoes 
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Frâncio está localizado no 7º período
da tabela periódica dos elementos. Isso significa que ele possui
7 níveis de energia em sua configuração eletrônica.
''')
    return informacoes 

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes
