def informacoes_gadolinio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do gadolínio é 64')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Gadolínio faz parte da família dos Lantanídeos,
que é um grupo de elementos de transição interna localizado
no período 6 da tabela periódica.
''')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Gadolínio é aproximadamente 157.25 u .')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Gadolínio é uma terra rara, branco prateado, maleável, dúctil com um brilho metálico.
Cristaliza na forma hexagonal que é a forma alfa, à temperatura ambiente. Quando 
aquecidoa 1508 K transforma-se na sua forma beta, que é uma estrutura 
cristalina cúbica de corpo centrado.
''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹⁰ 4f⁸
5s² 5p⁶
6s² 
''')
    return informacoes
    
  elif  pesquisa == 'origem do nome' or pesquisa == '7':
    informacoes = (''' 
O nome "Gadolínio" foi dado em homenagem ao químico finlandês Johan Gadolin,
que foi um dos primeiros a isolar ítrio, outro elemento dos lantanídeos.
''')
    return informacoes
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Gadolínio está localizado no 6º período da tabela periódica,
o que significa que ele tem 6 níveis de energia em sua 
configuração eletrônica.
''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes