def informacoes_galio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Gálio é 31.')
    return informacoes 
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
Pertence ao grupo 13 da tabela periódica, também conhecido como o grupo do Boro.
''')
    return informacoes 
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Gálio é aproximadamente 69,72 u.')
    return informacoes 
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Gálio é um metal macio, prateado e brilhante à temperatura ambiente. 
É sólido em condições normais, mas tem um ponto de fusão baixo,
tornando-o um dos poucos metais que podem ser facilmente fundidos 
em uma mão humana.
''')
    return informacoes 
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p¹
''')
    return informacoes 
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O nome "Gálio" deriva da palavra latina "Gallia", que significa França.
O elemento foi nomeado em homenagem ao país onde foi descoberto. 
''')
    return informacoes 
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Gálio está localizado no 4º período da tabela periódica. Isso significa que ele 
possui 4 níveis de energia na sua configuração eletrônica.
''')
    return informacoes 

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes