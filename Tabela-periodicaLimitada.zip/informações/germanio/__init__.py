def informacoes_germanio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Germânio é 32')
    return informacoes 
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Germânio pertence ao grupo 14 da tabela periódica,
que também é conhecido como o grupo do carbono.
''')
    return informacoes 
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Germânio é aproximadamente 72,63 u.')
    return informacoes 
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Germânio é um elemento químico sólido que é frequentemente usado em
eletrônica devido às suas propriedades semicondutoras. É um metalóide que
possui características intermediárias entre metais e não metais.
''')
    return informacoes 
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p²
''')
    return informacoes 
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O nome "Germânio" deriva do latim "Germania," que é uma referência à Alemanha, 
onde o elemento foi descoberto em 1886 por Clemens Winkler. O nome foi escolhido
em homenagem ao país de origem do descobridor. 
''')
    return informacoes 
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Germânio está localizado no 4º período da tabela periódica. Isso significa que ele
possui 4 níveis de enrgia na sua configuração eletrônica.
''')
    return informacoes 

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes