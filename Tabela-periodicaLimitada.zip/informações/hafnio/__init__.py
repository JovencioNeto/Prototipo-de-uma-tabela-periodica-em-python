def informacoes_hafnio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Háfnio é 72.')
    return informacoes 
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Háfnio pertence à família dos metais de transição,
especificamente ao Grupo 4 da tabela periódica.
A família do Háfnio inclui outros elementos como
o titânio (Ti), o zircônio (Zr) e o rutherfordio (Rf).
''')
    return informacoes 
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Háfnio é aproximadamente 178.49.')
    return informacoes 
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Háfnio é um metal de coloração acinzentada de baixa ocorrência natural na
crosta terrestre, com cerca de 5,3 mg para cada quilograma de crosta. Quando
finamente dividido, ele é um material pirofórico, ou seja, está propenso a uma
combustão espontânea em contato com o ar, contudo, em sua forma bruta, não.
''')
    return informacoes 
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹⁰ 4f¹⁴
5s² 5p⁶ 5d²
6s²
''')
    return informacoes 
    
  elif  pesquisa == 'origem do nome' or pesquisa == '7':
    informacoes = ('''
O nome "Háfnio" deriva do termo latino "Hafnia",
que é a palavra em latim para Copenhague, a capital
da Dinamarca. O Háfnio recebeu esse nome em homenagem à
nação onde foi descoberto. O Háfnio é um elemento químico
que foi isolado pela primeira vez em 1923 por Dirk Coster
e George Charles de Hevesy, dois químicos dinamarqueses.
Eles descobriram o Háfnio enquanto estavam trabalhando em
amostras de minerais de zircônio e conseguiram separar o 
Háfnio do zircônio.
''')
    return informacoes 
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Háfnio está localizado no 6º período da tabela periódica.
Isso significa que ele possui 6 níveis de energia em 
sua configuração eletrônica. Os elementos no mesmo 
período compartilham características químicas 
semelhantes devido à estrutura de camadas 
eletrônicas semelhantes.
''')
    return informacoes 
    
  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes