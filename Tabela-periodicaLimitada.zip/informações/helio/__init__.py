def informacoes_helio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Hélio é 2.')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
Os gases nobres são os elementos da família 18 da Tabela Periódica,
que são: Hélio , Neônio, Argônio, Criptônio, Xenônio e Radônio.
''')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('O Hélio possui 4,002602 u de massa.')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O gás Hélio é usado para o enchimento de balões e como líquido refrigerador de 
materiais supercondutores.
Outra aplicação é como gás engarrafado, utilizado por mergulhadores de grande 
profundidade.
''')
    return informacoes

  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
''')
    return informacoes
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O nome masculino Hélio deriva da palavra grega hḗlios (ἥλιος),
que posteriormente foi latinizada como Helius com os significados de “Sol”, “leste”, 
“dia”, “luz do sol”.
Na mitologia grega, Hélio era a personificação do Sol.
''')
    return informacoes
    
  elif pesquisa == 'período' or pesquisa == 'periodo' or pesquisa == '7':
    informacoes = ('''
O Hélio (He) é um elemento químico gasoso, não metálico,
pertencente ao grupo dos gases nobres, incolor, inodoro e não tóxico,
que se localiza no grupo 18 e período 1 da Tabela Periódica.
''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes