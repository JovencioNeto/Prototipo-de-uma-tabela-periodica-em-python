def informacoes_hidrogenio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Hidrogênio é 1.')
    return informacoes
    
  elif pesquisa == 'família' or pesquisa == 'familia' or pesquisa == '2':
    informacoes =('''
O Hidrogênio é um elemento químico que não possui família periódica, 
participa da composição de diversas substâncias e apresenta ampla utilização.
''')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('O Hidrogênio possui 1,00784 u de massa.')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes =('''
Trata-se de uma substância gasosa, inflamável, incolor, inodora, não metálica e
insolúvel em água. O ponto de fusão do hidrogênio molecular é -259,2 ºC e o ponto
de ebulição é -252,9 º C.
  ''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes =('''
1s¹
  ''')
    return informacoes
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O nome Hidrogênio deriva do grego hydro e genes, que significa gerador de água.
Foi descoberto em Londres, Inglaterra, pelo químico inglês Henry Cavendish (1731-1810)
em 1766, quando este identificou as suas propriedades e o designou por ar inflamável.
    ''')
    return informacoes
    
  elif pesquisa == 'período' or pesquisa == 'periodo' or pesquisa == '7':
    informacoes =('''
O Hidrogênio localiza-se no primeiro período da Tabela Periódica,
mas não pode ser incluído em nenhum grupo. É um gás incolor, inodoro, insolúvel na água,
menos denso que o ar e é o mais leve de todos os elementos.
  ''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes