def informacoes_holmio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Hólmio é 67.')
    return informacoes 
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Hólmio é um elemento de transição interna pertencente ao grupo dos lantanídeos 
ou terras-raras. É um metal branco prateado brilhante, é relativamente macio,
mole e flexível.
''')
    return informacoes 
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Hólmio é aproximadamente 164,93032 u.')
    return informacoes 
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Hólmio reage lentamente com ácidos minerais ou orgânicos que podem estar concentrados
ou diluídos desprendendo hidrogênio e formando sais. O Hólmio forma compostos como carbonato,
acetato, nitrato, hidreto, óxido, hidróxido, oxalato, cloreto, fluoreto, iodeto e sulfato.
''')
    return informacoes 
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹⁰ 4f¹¹
5s² 5p⁶
6s² 
''')
    return informacoes 
    
  elif pesquisa == 'origem do nome' or pesquisa == '7':
    informacoes = ('''
O nome "holmium" deriva do nome em latim "Holmia", que significa "Estocolmo".
O elemento recebeu esse nome em homenagem à capital da Suécia, Estocolmo, onde foi
descoberto. O Holmio foi descoberto em 1878 pelos químicos suíços Per Teodor Cleve e
Jacques-Louis Soret. É um elemento químico com o símbolo "Ho" e o número atômico 67.
''')
    return informacoes 
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Hólmio, com símbolo Ho e número atômico 67,
está localizado no 6º período da tabela periódica.
Isso significa que ele tem 6 níveis de energia 
em sua estrutura eletrônica. 
''')
    return informacoes 

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes