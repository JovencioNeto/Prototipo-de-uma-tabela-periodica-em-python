def informacoes_iodo(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Iodo é 53')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Iodo faz parte do grupo 17 da tabela periódica,
conhecido como o grupo dos halogênios.
''')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa atômica do Iodo é aproximadamente 126.904 u.')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Iodo é um sólido de cor roxa-escura ou preto-acastanhado em temperatura ambiente.
É um elemento essencial para o funcionamento adequado da glândula tireoide no corpo 
humano. 
''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹⁰
5s² 5p⁵ 
''')
    return informacoes
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
A palavra "Iodo" vem do grego "iodes," que significa "violeta".
Isso é uma referência à cor violeta dos vapores de iodo. 
''')
    return informacoes
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Iodo está localizado no período 5 da tabela periódica, o que significa 
que ele tem 5 níveis de energia em sua configuração eletrônica.
''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes
