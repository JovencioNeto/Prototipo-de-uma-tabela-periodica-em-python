def informacoes_iridio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Irídio é 77.')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Irídio (Ir) é um elemento químico com o número atômico 77
e pertence ao grupo 9 da tabela periódica.
''')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Irídio é aproximadamente 192,217 u.')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = (''' 
O Irídio não sofre ação de ataque de ácidos ou pela água régia,
mas pode ser atacado por alguns sais fundidos, como NaCl e NaCN.
A densidade deste elemento é a segunda mais alta conhecida, 
sendo o ósmio o mais denso.
''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹⁰ 4f¹⁴
5s² 5p⁶ 5d⁷
6s²
''')
    return informacoes
    
  elif  pesquisa == 'origem do nome' or pesquisa == '7':
    informacoes = ('''
O nome "Irídio" tem origem na palavra grega "íris", que significa "arco-íris".
O elemento Irídio recebeu esse nome devido às cores variadas e brilhantes dos
seus compostos. Quando o Irídio forma compostos, muitas vezes exibe cores vivas
e multicoloridas. A escolha desse nome foi uma referência à diversidade de cores
associadas aos compostos de Irídio.
''')
    return informacoes
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Irídio (Ir) está localizado no 6º período da tabela periódica. 
Isso significa que ele possui 6 camadas de energia na configuração eletrônica.
''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes