def informacoes_iterbio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Itérbio é 70.')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = (''' 
O Itérbio pertence à família dos lantanídeos,
também conhecida como lantanoides ou terras raras.
Essa família inclui todos os elementos do lantânio 
(La) ao lutécio (Lu) na tabela periódica.
''')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Itérbio é aproximadamente 173.04 u.')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Itérbio é um elemento macio, maleável e bastante dúctil que exibe um brilho prateado.
É uma terra rara, facilmente atacável e solúvel por ácidos minerais.
Reage lentamente com a água, e se oxida no ar.
''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = (''' 
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹⁰ 4f¹⁴
5s² 5p⁶
6s²
''')
    return informacoes
    
  elif  pesquisa == 'origem do nome' or pesquisa == '7':
    informacoes = ('''
O nome "Itérbio" deriva da palavra "Ytterby", que é uma aldeia
na Suécia. Ytterby é famosa por ter sido a fonte de muitos minerais
contendo elementos de terras raras, incluindo o Itérbio.
A aldeia de Ytterby deu origem a vários nomes de elementos químicos,
pois muitos dos primeiros elementos da família dos lantanídeos,
como o Itérbio, foram isolados de minerais encontrados nessa região.
''')
    return informacoes
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Itérbio está localizado no período 6 da tabela periódica.
Isso significa que ele possui seis níveis de energia em sua
configuração eletrônica.
''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes