def informacoes_itrio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do ítrio é 39')
    return informacoes 
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Ítrio pertence ao grupo 3 da tabela periódica,
que é frequentemente chamado de "grupo do escândio".
''')
    return informacoes 
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa atômica do ítrio é aproximadamente 88,905 u.')
    return informacoes 
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O ítrio é um metal de transição prateado, duro e brilhante.
É usado em várias aplicações,
incluindo em lâmpadas de vapor de mercúrio para produzir luz branca,
em lasers de ítrio-alumínio-granada (YAG),
e como um componente em ligas metálicas em aplicações aeroespaciais e médicas,
entre outros usos.
''')
    return informacoes 
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹
5s²
''')
    return informacoes 
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O nome "ítrio" foi derivado da região sueca de Ytterby,
onde foram encontrados minerais que continham ítrio.
''')
    return informacoes 
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Ítrio está localizado no 5° período da tabela periódica. Isso significa que ele
possui 5 níveis de energia na sua configurção eletrônica. 
''')
    return informacoes 

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes