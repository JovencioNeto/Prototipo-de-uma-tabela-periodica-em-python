def informacoes_lantanio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Lantânio é 57.')
    return informacoes 
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Lantânio pertence ao grupo 3 da tabela periódica e faz parte do grupo dos Lantanídeos.
''')
    return informacoes 
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Lantânio é aproximadamente 138.904 u.')
    return informacoes 
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Lantânio é um metal de transição de cor prateada que é altamente reativo quando
exposto ao ar. Ele é encontrado em minerais de lantânio e é usado em aplicações
como lâmpadas de arco elétrico, baterias de hidreto metálico de níquel-lantânio
e catalisadores. 
''')
    return informacoes 
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹⁰ 4f¹
5s² 5p⁶ 
6s² 
''')
    return informacoes 
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O nome "Lantânio" deriva do termo grego "lanthanein," que significa "estar escondido".
Foi assim chamado porque era difícil de isolar e identificar no início
da sua descoberta.
''')
    return informacoes 
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Lantânio está localizado no 6° período da tabela periódica, 
o que significa que ele tem 6 níveis de energia em sua 
configuração eletrônica.
''')
    return informacoes 

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes