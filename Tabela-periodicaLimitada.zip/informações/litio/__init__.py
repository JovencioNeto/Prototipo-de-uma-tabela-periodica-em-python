def informacoes_litio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico'  or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico deste elemento é 3.')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
Pertence à família 1A da classificação periódica dos elementos químicos,
o que o torna um metal alcalino.
''')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('O elemento possuir 6,941 u de massa atômica.')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O lítio é um metal de coloração branco acinzentada pertencente ao grupo dos 
metais alcalinos.
É bastante reativo e possui a menor densidade dentre os metais,
além de ser o mais eletropositivo dentre eles.
''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s¹
''')
    return informacoes
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O seu nome deriva do grego lithos, que significa pedra,
já que o elemento é encontrado em rochas.
''')
    return informacoes
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Litio localiza-se no grupo 1 e período 2 da Tabela Periódica.
Isso significa que ele possui 2 camadas de energia na sua 
distribuição eletrônica.
''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes