def informacoes_magnesio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Magnésio é 12. ')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Magnésio faz parte do Grupo 2 da tabela periódica, 
dos chamados metais alcalino-terrosos
''')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('O Magnésio possui 24,305 u de massa.')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
Quando finamente dividido, sua combustão produz uma luz branca e intensa.
É o oitavo elemento mais abundante da crosta terrestre, sendo encontrado principalmente
nos minerais magnesita e dolomita.
''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶
3s²
''')
    return informacoes
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
Magnésio, da expressão latina magnesia alba (magnésia branca), nome dado ao carbonato
de Magnésio MgCO3. O nome magnésia, no entanto, parece ter tido origem na Grécia antiga;
Magnésia era um distrito de Tessália, Grécia.
''')
    return informacoes
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Magnésio (Mg) é um elemento químico pertencente ao grupo dos metais alcalinoterrosos,
bivalente, de cor branco-prateada, leve e com brilho prateado, que se localiza no grupo
2 e 3º período da Tabela Periódica. Isso signfica que ele possui 3 níveis de energia na
sua configuração eletrônica.
''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes