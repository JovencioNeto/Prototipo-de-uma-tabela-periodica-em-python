def informacoes_manganes(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes =('O número atômico do Manganês é 25.')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes =('''
O Manganês pertence ao grupo 7 da tabela periódica, que também é conhecido
como o grupo dos metais de transição.
''')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes =('A massa do Manganês é aproximadamente 54,94 u.')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes =('''
O Mangânes é um metal de cor cinza prateado. 
É um elemento de transição com propriedades metálicas típicas.
''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes =('''
1s²
2s² 2p⁶
3s² 3p⁶ 3d⁵
4s²
''')
    return informacoes
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes =('''
O nome "Mangânes" tem origem no termo grego "magnesia," que se 
referia a uma região na Grécia conhecida por suas minas de Mangânes.
A palavra "magnesia" foi usada para descrever o minério de Mangânes. 
''')
    return informacoes
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes =('''
O Mangânes está localizado no 4º período da tabela periódica, o que significa que 
está na quarta linha horizontal da tabela, contando de cima para baixo. Isso ignifica
qu ele possui 4 níveis de energia na sua configuração eletrônica.
''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes