def informacoes_mercurio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Mercúrio é 80.')
    return informacoes

  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Mercúrio pertence à família dos metais de transição na tabela periódica dos elementos.
Mais especificamente, está localizado no grupo 12, que é também conhecido como o grupo dos 
metais de transição externa. A família do Mercúrio inclui outros elementos como o zinco (Zn) 
e o cádmio (Cd). Esses elementos compartilham propriedades físicas e químicas semelhantes,
dada sua posição na tabela periódica.
  ''')
    return informacoes

  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Mercúrio é aproximadamente 200.59 u.')
    return informacoes

  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Mercúrio é um metal líquido à temperatura ambiente, conhecido desde os tempos da Grécia Antiga. Também é conhecido como hidrargírio, hidrargiro, azougue e prata-viva, entre outras denominações. Seu nome homenageia o deus romano Mercúrio, que era o mensageiro dos deuses. Essa homenagem é devida à fluidez do metal. O símbolo Hg vem do grego latinizado 'hydrargyrum' que significa prata líquida.
''')
    return informacoes

  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹⁰ 4f¹⁴
5s² 5p⁶ 5d¹⁰
6s²
  ''')
    return informacoes

  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O nome "Mercúrio" tem origens na mitologia romana, onde Mercúrio era o nome do
mensageiro dos deuses, conhecido por sua velocidade e habilidades de comunicação.
Na mitologia grega, a contraparte de Mercúrio é Hermes. O planeta Mercúrio também
recebeu o nome do deus romano.
  ''')
    return informacoes

  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Mercúrio está localizado no 6º período da tabela periódica dos elementos.
Isso significa que o mercúrio tem 6 níveis de energia ou camadas eletrônicas
ao redor do núcleo atômico. 
  ''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes

