def informacoes_molibenio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Molibdênio é 42.')
    return informacoes 
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Molibdênio está localizado no grupo 6 da tabela periódica,
que é conhecido como o grupo dos "cromatos".
''')
    return informacoes 
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Molibdênio é aproximadamente 95.95 u.')
    return informacoes 
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Molibdênio é um metal de transição de cor prateada e brilhante. É
usado em diversas aplicações industriais e é um componente importante
em ligas metálicas e em catalisadores.
''')
    return informacoes 
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d⁴
5s²
''')
    return informacoes 
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O nome "molibdênio" tem origem no grego "molybdos", que significa chumbo,
porque o minério de molibdênio era frequentemente confundido com minérios de chumbo.
O elemento foi isolado pela primeira vez por Peter Jacob Hjelm em 1781.
''')
    return informacoes 
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O molibdênio está localizado no 5º período da tabela periódica,
o que significa que ele tem 5 níveis de energia em sua 
configuração eletrônica.
''')
    return informacoes 

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes