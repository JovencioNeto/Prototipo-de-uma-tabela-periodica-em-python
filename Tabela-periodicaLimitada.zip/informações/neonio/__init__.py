def informacoes_neonio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do neonio é 10.')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
É conhecido pelo nome de Neônio ou ainda Neon,
um elemento químico classificado como gás nobre.
''')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('O Neônio possui 20,1797 u de massa.')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Neônio é um gás monoatômico, não inflamável, não tóxico, incolor, inodoro e insípido.
Ele existe em uma quantidade muito pequena na atmosfera (18,18 ppm/volume).
O neônio é normalmente comercializado como gás comprimido em cilindros de aço e
também em frascos de vidro de um litro na pressão atmosférica.
''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶
''')
    return informacoes
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('Neônio, do grego neos, novo.')
    return informacoes
    
  elif pesquisa == 'Periodo' or pesquisa == 'periodo' or pesquisa == 'período':
    informacoes = ('''
O Neônio é o segundo gás nobre e pertence ao 2º 
período da tabela periódica. Isso significa que ele 
possui 2 níveis de energia na sua configuração eletrônica.
''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes