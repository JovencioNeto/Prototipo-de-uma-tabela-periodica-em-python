def informacoes_netunio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Netúnio é 93.')
    return informacoes

  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
 É o quarto elemento da família dos actinídeos.
  ''')
    return informacoes

  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Netúnio é aproximadamente 237,0482 u.')
    return informacoes

  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
É um elemento metálico, radioativo, prateado, pertencente à série dos elementos
de transição interna, sendo o primeiro elemento transurânico sintético.
Seu isótopo mais estável, Np-237, é um subproduto de reatores nucleares
e produção de plutônio. Pode ser usado na composição de equipamentos para
a detecção de nêutrons e como combustível nuclear.
  ''')
    return informacoes

  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s² 
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹⁰ 4f¹⁴
5s² 5p⁶ 5d¹⁰ 5f⁵
6s² 6p⁶
7s²
  ''')
    return informacoes

  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O Neptúnio (português europeu) ou Netúnio[1] (português brasileiro)
(em homenagem ao planeta Netuno) é um elemento químico sintético de símbolo Np,
com número atômico 93 (93 prótons e 93 elétrons).
  ''')
    return informacoes

  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Neptúnio, símbolo Np, é um metal pertencente à série dos actinídeos,
localizada no sétimo período, grupo 3, da Tabela Periódica.
  ''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes

