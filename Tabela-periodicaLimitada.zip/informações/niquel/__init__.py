def informacoes_niquel(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Níquel é 28.')
    return informacoes 
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Níquel pertence à família dos metais de transição,
especificamente ao grupo 10 da tabela periódica.
''')
    return informacoes 
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Níquel é aproximadamente  58,69 u.')
    return informacoes 
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Níquel é um metal de cor prateada e brilhante. Ele é resistente à corrosão e é 
conhecido por sua durabilidade.O níquel é amplamente utilizado na indústria,
especialmente na fabricação de moedas, baterias, ligas metálicas e
revestimentos de objetos metálicos. 
''')
    return informacoes 
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d⁸
4s²
''')
    return informacoes 
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O nome "Níquel" deriva do termo alemão "Kupfernickel", que significa 
"demônio do cobre" ou "espírito maligno do cobre".O níquel era 
originalmente confundido com minerais de cobre, e a 
sua extração foi muitas vezes difícil. 
''')
    return informacoes 
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Níquel está localizado no 4º período da tabela periódica, o que significa que ele 
tem 4 níveis de energia em sua distribuição eletrônica.
''')
    return informacoes 

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes