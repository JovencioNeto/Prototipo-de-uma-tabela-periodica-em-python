def informacoes_nitrogenio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Nitrogênio é 7.')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Nitrogênio, cujo símbolo é N, é o elemento químico não metálico (ametal)
localizado na família VA ou grupo 15 (família do Nitrogênio)
e no 2º período da tabela periódica.
''')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('O Nitrogênio possui 14,0067 u de massa.')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Nitrogênio (azoto, do grego "a", sem e "zoe", vida), que significa
“formador de salitre” ou "o que forma nitratos". É um dos elementos 
mais abundantes no Universo. Na Terra está em sua maior parte, em estado gasoso, 
chegando a preencher 78% do volume do ar atmosférico.
''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p³
''')
    return informacoes
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O Nitrogênio (azoto, do grego "a", sem e "zoe", vida),
que significa “formador de salitre” ou "o que forma nitratos".
''')
    return informacoes
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Nitrogênio fica ocalizado na família VA(nome dado
à 15º coluna vertical da tabela periódica)
ou grupo 15 (família do Nitrogênio) e no 2º período 
da tabela periódica.
''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes