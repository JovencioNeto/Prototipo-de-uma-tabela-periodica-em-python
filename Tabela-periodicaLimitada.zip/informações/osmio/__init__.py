def informacoes_osmio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Ósmio é 76.')
    return informacoes 
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Ósmio é um elemento químico com o símbolo Os e número atômico 76 na 
tabela periódica. Ele pertence ao grupo 8 da tabela periódica,
que é frequentemente chamado de grupo do ferro. 
''')
    return informacoes 
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Ósmio é aproximadamente 190,23 u.')
    return informacoes 
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Ósmio em sua forma metálica é o elemento mais denso da tabela peiódica,
branco azulado, frágil, sólido e brilhante, inclusive a altas temperaturas,
mesmo sendo difícil encontrá-lo nesta forma. É mais fácil obter o ósmio na 
forma de pó, mesmo que exposto ao ar tende a formação do tetróxido de ósmio,
OsO4. O tetróxido de ósmio é tóxico (perigoso para os olhos), oxidante 
energético e volátil com um forte odor.
''')
    return informacoes 
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹⁰ 4f¹⁴
5s² 5p⁶ 5d⁶
6s²
''')
    return informacoes 
    
  elif  pesquisa == 'origem do nome' or pesquisa == '7':
    informacoes = ('''
O nome "Ósmio" tem origem no grego "osmē", que significa "odor" ou "cheiro".
Este nome foi dado ao elemento devido à sua tendência de formar compostos
com um odor muito desagradável. O Ósmio é conhecido por formar óxidos voláteis
que emitem um odor desagradável quando são aquecidos. Além disso, esses compostos
voláteis de Ósmio eram usados na época de sua descoberta para fins de fixação 
fotográfica, e o odor era considerado desagradável pelos químicos que trabalhavam
com ele.
''')
    return informacoes 
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Ósmio (Os) está localizado no 6º período da tabela periódica.
Isso significa que ele possui 6 niveis de energia na sua configuração eletrônica.
''')
    return informacoes 
    
  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes