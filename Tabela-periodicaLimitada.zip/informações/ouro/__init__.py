def informacoes_ouro(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Ouro é 79.')
    return informacoes

  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Ouro pertence à família dos metais de transição e está localizado no grupo 11 
Tabela Periódica dos elementos.
  ''')
    return informacoes

  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Ouro é aproximadamente 196.967 u.')
    return informacoes

  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Ouro é resistente à maioria dos ácidos, embora se dissolva em água régia (uma mistura
de ácido nítrico e ácido clorídrico ), formando um anião tetracloroáurico solúvel.
O Ouro é insolúvel apenas em ácido nítrico, que dissolve prata e metais básicos,
propriedade há muito utilizada para refinar ouro e confirmar a presença de Ouro
em substâncias metálicas, dando origem ao termo ' teste ácido '. O Ouro dissolve-se
em soluções alcalinas de cianeto , que são usadas em mineração e galvanoplastia .
O Ouro também se dissolve em mercúrio , formando ligas de amálgama , e como o Ouro
age simplesmente como um soluto, não se dá uma reação química 
  ''')
    return informacoes

  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹⁰ 4f¹⁴
5s² 5p⁶ 5d⁹
6s²
  ''')
    return informacoes

  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O nome "Ouro" tem origens antigas e deriva do latim. A palavra em latim para ouro é 
"aurum". Essa raiz linguística é compartilhada por várias línguas, como o espanhol
("oro"), o francês ("or"), o italiano ("oro"), entre outras. A escolha do termo "aurum" 
no latim reflete a apreciação antiga por esse metal precioso devido às suas propriedades 
únicas, como a cor brilhante e a resistência à corrosão.

  ''')
    return informacoes

  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
Na tabela periódica dos elementos, o Ouro está localizado no 6º período.
O número do período em que um elemento está na tabela periódica corresponde
ao número quântico principal de seus elétrons. Em outras palavras, significa 
que o Ouro possui 6 níveis de energia em sua configuraçãoe eletrônica.
  ''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes
