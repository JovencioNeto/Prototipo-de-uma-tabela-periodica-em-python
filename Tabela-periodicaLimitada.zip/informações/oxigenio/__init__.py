def informacoes_oxigenio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Oxigênio é 8.')
    return informacoes 
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Oxigênio, cujo símbolo é O, é o elemento químico não metálico (ametal)
localizado na família VIA ou grupo 16 (família dos calcogênios)
e no 2º período da tabela periódica.
''')
    return informacoes 
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('O elemento possui 15,999 u de massa atômica')
    return informacoes 
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O OxigÊnio em estado gasoso, é incolor — mas apresenta cor azulada
em estado líquido e sólido. Também é inodoro (sem cheiro) e insípido (sem gosto). 
Mesmo sendo necessário para processos de combustão, ele não é combustível, além de
ser pouco solúvel em água.
''')
    return informacoes 
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁴
''')
    return informacoes 
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
Do grego oxis (ácido) e genes (produtor), o Oxigênio foi descoberto em 1773
pelo sueco Carl Wilhelm Scheele. Na ocasião, o farmacêutico realizava uma experiência
de calcinação do nitrato de potássio.
''')
    return informacoes 
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Oxigênio pertence ao 2º período da tabela periódica.
Isso significa que ele possui 2 camadas de energia na sua 
configuração eletrônica.
''')
    return informacoes 

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes