def informacoes_platina(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico da Platina é 78.')
    return informacoes

  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
A platina pertence à família dos metais de transição, que é um grupo de elementos
localizados no bloco D da tabela periódica. Mais especificamente, a platina faz parte
do grupo 10, que é conhecido como a "família da platina" ou "família do níquel". Essa
família inclui os elementos níquel (Ni), paládio (Pd), platina (Pt), darmstádio (Ds) e
meitnério (Mt)
  ''')
    return informacoes

  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa da Platina é aproximadamente 195,085 u.')
    return informacoes

  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
É um metal dúctil, maleável, de coloração branca prateada. Em qualquer temperatura,
a Platina não sofre corrosão pelo ar atmosférico, mas sim por cianetos, haletos,
sulfetos e bases muito fortes e corrosivas.
  ''')
    return informacoes

  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹⁰ 4f¹⁴
5s² 5p⁶ 5d⁸
6s²
  ''')
    return informacoes

  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O nome "Platina" tem origens na língua espanhola, e é derivado da palavra "platina",
que significa "pequena prata". O nome reflete a semelhança da platina com a prata em 
termos de cor e brilho. A platina foi descoberta na América do Sul por exploradores
espanhóis no século XVI, durante a colonização das Américas.
''')
    return informacoes

  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O período da Platina na tabela periódica é o 6º período. Isso significa que ela
possui 6 níveis de energia em sua configuração eletrônica.
''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes

