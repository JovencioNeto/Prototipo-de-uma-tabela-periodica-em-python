def informacoes_plutonio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Plutônio é 94.')
    return informacoes

  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
Pertencente a família dos actinídeos, é um metal radioativo, frágil,
muito denso e de cor prateada-branca, que embaça em contato com o ar,
formando um revestimento amorfo quando oxidado.
  ''')
    return informacoes

  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Plutônio é aproximadamente 244 u.')
    return informacoes

  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Plutônio (português europeu) ou plutônio (português brasileiro)
(em homenagem ao corpo celeste Plutão) é um elemento químico representado
pelo símbolo Pu e de número atômico igual a 94 (94 protões e 94 electrões).
  ''')
    return informacoes

  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s² 
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹⁰ 4f¹⁴
5s² 5p⁶ 5d¹⁰ 5f⁶
6s² 6p⁶
7s²
  ''')
    return informacoes

  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
Este elemento foi obtido pela primeira vez em 1940 na Universidade de Berkeley,
na Califórnia, nos Estados Unidos da América, pelo químico norte americano G. T.
Seaborg e seus colaboradores mediante a irradiação de urânio com deuterões.
O nome plutônio deriva do nome do planeta Plutão.
  ''')
    return informacoes

  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Plutônio (Pu) é um elemento químico sintético e radioativo que pertence 
ao grupo dos transuranídeos e localiza-se no grupo 3 e período 7 da Tabela Periódica.
  ''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes

