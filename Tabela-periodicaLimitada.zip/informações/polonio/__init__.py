def informacoes_polonio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O Número Atômico do Polônio é 84.')
    return informacoes

  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Polônio é um elemento químico de número atômico 84,
pertence ao 6º período da família 16 (calcogênios) da tabela periódica
''')
    return informacoes

  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('O Polônio possui 209 u de massa.')
    return informacoes

  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Polônio é radioativo, dissolvendo-se facilmente em ácidos diluídos, porém só
é levemente solúvel em álcalis. É quimicamente semelhante ao bismuto e ao telúrio,
sendo mais eletropositivo que o telúrio e o selênio, elementos da mesma família.
  ''')
    return informacoes

  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹⁰ 4f¹⁴
5s² 5p⁶ 5d¹⁰
6s² 6p⁴
  ''')
    return informacoes

  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
Seu nome é uma referência ao país Polônia, terra natal de Marie Curie, 
que trabalhando em conjunto com seu marido, Pierre, isolou pela primeira vez 
o elemento em 1898.
  ''')
    return informacoes
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Polônio é um elemento químico que se encontra no grupo 16 (antigo grupo 6A)
da tabela periódica. Fica logo abaixo do telúrio. Além disso,
faz parte do período 6, situado entre o bismuto e o astato.
  ''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes