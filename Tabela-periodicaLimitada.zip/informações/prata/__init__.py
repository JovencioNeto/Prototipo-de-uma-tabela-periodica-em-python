def informacoes_prata(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico da Prata é 47.')
    return informacoes 
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
A Prata pertence ao grupo 11 da tabela periódica, 
que é conhecido como o grupo dos "metais de transição".
''')
    return informacoes 
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa da Prata é aproximadamente 107.87 u.')
    return informacoes 
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
A Prata é um metal nobre de cor branca brilhante que é conhecido por sua beleza 
e sua alta condutividade elétrica e térmica. É frequentemente usado em joias, moedas,
utensílios de mesa e em eletrônica devido às suas propriedades únicas. 
''')
    return informacoes 
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d⁹
5s²
''')
    return informacoes 
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
A palavra "Prata" tem origem no latim "argentum". O símbolo químico "Ag" também 
deriva de "argentum". A prata tem sido usada por milênios em moedas e 
joias e é conhecida por sua durabilidade e brilho.
''')
    return informacoes 
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
A Prata está localizada no 5º período da tabela periódica,
o que significa que ela tem 5 níveis de energia em sua 
configuração eletrônica.
''')
    return informacoes 
  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes