def informacoes_promecio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Promécio é 61')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Promécio é classificado como um elemento do 3º grupo da tabela periódica.
''')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Promécio é aproximadamente 145 u.')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa =='4':
    informacoes = ('''
O Promécio é um elemento metálico radioativo que é raramente encontrado na natureza.
Geralmente, é produzido artificialmente em reatores nucleares.Devido à sua 
radioatividade, o promécio tem aplicações limitadas e é usado principalmente 
em dispositivos de fontes de energia nucleares pequenas,como baterias nucleares. 
''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹⁰ 4f⁵
5s² 5p⁶
6s²
''')
    return informacoes
    
  elif  pesquisa == 'nome' or pesquisa == '6':
    informacoes = ('''
O nome "Promécio" deriva do termo grego "Prometheus",
que significa "aquele que antecede" ou "previsão".
Foi nomeado assim devido à propriedade de emitir radiação,
que pode ser prevista. 
''')
    return informacoes
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Promécio está localizado no 6° período da tabela periódica,
o que significa que ele tem 6 níveis de energia em sua 
configuração eletrônica.
''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes
    