def informacoes_protactinio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Protactínio é 91.')
    return informacoes

  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Protactínio (Pa) é um elemento químico metálico radioativo que pertence
ao grupo dos actinídeos e localiza-se no grupo 3 e período 7 da Tabela Periódica.
  ''')
    return informacoes

  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Protactínio é aproximadamente 231.03588 u.')
    return informacoes

  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Protactínio é um metal pertencente ao bloco f da Tabela Periódica. Na forma metálica, 
é dúctil e maleável. Em solução, seu principal NOx é +5, tal qual tântalo e nióbio.
Possui 29 isótopos conhecidos, sendo apenas dois encontrados na natureza: os de 
massa 231 e 234.
  ''')
    return informacoes

  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s² 
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹⁰ 4f¹⁴
5s² 5p⁶ 5d¹⁰ 5f³
6s² 6p⁶
7s²
  ''')
    return informacoes

  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O nome Protactínio deriva do grego protos que significa primeiro.
É um dos elementos mais escassos da Terra.
  ''')
    return informacoes

  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Protactínio (Pa) é um elemento químico metálico radioativo que pertence ao grupo
dos actinídeos e localiza-se no grupo 3 e período 7 da Tabela Periódica.
  ''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes

