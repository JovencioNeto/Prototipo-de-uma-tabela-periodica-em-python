def informacoes_radio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Rádio é 88.')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('O Rádio pertence à família dos metais alcalino-terrosos.')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Rádio é aproximadamente 226,025 u .')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Rádio é um elemento radioativo altamente instável,
devido à sua tendência à decaimento radioativo.
É extremamente raro na natureza e é produzido como um subproduto
da degradação de minerais de urânio e tório.
''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s² 
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹⁰ 4f¹⁴
5s² 5p⁶ 5d¹⁰ 
6s² 6p⁶
7s²
''')
    return informacoes
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
A palavra "Rádio" tem sua origem no termo latino "radius",
que significa "raio".
A escolha desse nome está relacionada às propriedades radioativas do elemento,
que emitem partículas e radiações em várias direções,
como se fossem "raios" invisíveis.
''')
    return informacoes
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Rádio ocalizado no 7° período da tabela periódica. O que significa que ele possui 7
camadas de energia na sua configuração eletrônica.
''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes
    
