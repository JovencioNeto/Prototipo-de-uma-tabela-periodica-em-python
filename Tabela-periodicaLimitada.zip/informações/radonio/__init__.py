def informacoes_radonio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Radônio é 86.')
    return informacoes

  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Radônio é gasoso radioativo, enquadrado dentro dos chamados "gases nobres".
Na forma gasosa, é incolor, inodoro e insípido; na forma sólida, tem cor
avermelhada. Na tabela periódica, situa-se no grupo 18
(antigo grupo VIIIA), com o número atômico 86 e 
símbolo Rn.
  ''')
    return informacoes

  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Radônio é aproximadamente  222 u.')
    return informacoes

  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
Ao contrário dos outros descendentes do urânio, o Radônio é gasoso e pertence à 
família dos gases nobres, libertando-se dos solos e rochas, materiais de construção
e água, sendo que no seu processo natural de decaimento emite partículas alfa, beta
e radiação gama. A radioatividade emitida pelo radão a que uma pessoa está exposta,
em Portugal, segundo o ITN, equivale em média a 56,7% da radiação ionizante que 
essa pessoa está sujeita.
  ''')
    return informacoes

  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹⁰ 4f¹⁴
5s² 5p⁶ 5d¹⁰
6s² 6p⁶
  ''')
    return informacoes

  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O elemento rádon/radão/radónio ou radônio (do latim radonium - derivado do rádio)
é um elemento químico com o símbolo Rn. Foi descoberto por Robert Bowie Owens
e Ernest Rutherford em 1899. Recebe esse nome devido ser uns do vários derivados
do elemento Rádio.
  ''')
    return informacoes

  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Radônio é um gás nobre do 6º período da Tabela Periódica.
Isso significa que ele possui 6 níveis de energia em sua 
configuração eletrônica.
  ''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes

