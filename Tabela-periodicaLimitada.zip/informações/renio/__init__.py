def informacoes_renio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Rênio é 75.')
    return informacoes 
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Rênio pertence ao grupo 7 da tabela periódica, 
também conhecido como o grupo do manganês.
Portanto, a família do Rênio está no Grupo
7 da tabela periódica. 
''')
    return informacoes 
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Rênio é aproximadamente 186,2 u.')
    return informacoes 
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Rênio é um metal branco prateado, brilhante, que apresenta um 
dos maiores pontos de fusão, excedido somente pelo Tungsténio e 
pelo Carbono. É também um dos mais densos, excedido somente pela
platina, pelo irídio, e pelo ósmio. Os estados de oxidação do Rênio
incluem -1,+1,+2,+3,+4,+5,+6 e +7, sendo os mais comuns +7,+6,+4,+2 e -1.
''')
    return informacoes 
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹⁰ 4f¹⁴
5s² 5p⁶ 5d⁵
6s²
''')
    return informacoes 
    
  elif  pesquisa == 'origem do nome' or pesquisa == '7':
    informacoes = ('''
O nome "Rênio" tem origem na palavra latina "rhenus", que significa "rio Reno".
O elemento químico Rênio recebeu esse nome em homenagem ao rio Reno, que é um
dos rios mais importantes da Europa. 
''')
    return informacoes 
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Rênio (símbolo Re, número atômico 75) pertence ao 6º período da tabela periódica.
Isso significa que ele possui 6 camadas de energia na sua configuração eletrônica.
''')
    return informacoes 

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes
