def informacoes_rodio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Ródio é 45')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Ródio pertence ao grupo 9 da tabela periódica,
que é conhecido como o grupo dos "metais de transição".
''')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Ródio é aproximadamente 102.91 u.')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Ródio é um metal de transição branco-prateado e resistente à corrosão.
É conhecido por sua alta refletividade à luz e é usado em joias 
e em várias aplicações industriais, como catalisadores. 
''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d⁷
5s²
''')
    return informacoes
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O nome "Ródio" deriva do grego "rhodon", que significa "rosa",
devido à cor rosa-avermelhada dos seus sais. Foi descoberto em 1803
por William Hyde Wollaston. 
''')
    return informacoes
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Ródio está localizado no 5º período da tabela periódica,
o que significa que ele tem 5 níveis de energia em 
sua configuração eletrônica.
''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes