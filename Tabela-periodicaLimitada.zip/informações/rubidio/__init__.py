def informacoes_rubidio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Rubídio é 37.')
    return informacoes 

  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Rubídio pertence à família dos metais alcalinos na tabela periódica 
dos elementos. 
''')
    return informacoes 

  elif  pesquisa == 'peso':
    informacoes = ('A massa do Rubídio é aproximadamente 85,4678 u .')
    return informacoes 

  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Rubídio (Rb) é um metal alcalino prateado altamente reativo.
Possui número atômico 37 e é usado em relógios atômicos para medição
precisa do tempo e em aplicações de ressonância magnética nuclear.
''')
    return informacoes 

  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s² 
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰ 
4s² 4p⁶ 
5s¹
''')
    return informacoes 

  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O nome "Rubídio" é o nome oficial do elemento químico com o símbolo "Rb".
Esse nome é derivado da palavra latina "rubidus", que significa "vermelho",
em referência à cor vermelha característica das linhas espectrais do elemento
quando analisado por espectroscopia.
''')
    return informacoes 

  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Rubídio está localizado no quinto período da tabela periódica
dos elementos.Isso significa que ele posssui 5 níveis de energia na sua 
configuração eletrônica.
''')
    return informacoes 

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes