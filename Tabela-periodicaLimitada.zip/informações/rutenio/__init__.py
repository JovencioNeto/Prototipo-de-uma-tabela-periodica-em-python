def informacoes_rutenio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Rutênio é 44.')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Rutênio pertence à família dos metais de transição,
especificamente ao Grupo 8 da Tabela Periódica.
''')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Rutênio é aproximadamente 101,07 u.')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Rutênio é um metal de transição branco prateado que é conhecido por sua resistência à
corrosão. É frequentemente utilizado em ligas metálicas devido a suas propriedades
físicas e químicas. 
''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d⁶
5s²
''')
    return informacoes
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O nome "Rutênio" deriva do latim "Ruthenia," que significa "Rússia".
O elemento foi descoberto pelo químico russo Karl Karlovich Klaus em 1844. 
''')
    return informacoes
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Rutênio está localizado no 5º período da tabela periódica,
o que significa que ele possui 5 níveis de energia 
em sua configuração eletrônica.
''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes