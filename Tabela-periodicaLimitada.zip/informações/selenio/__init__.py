def informacoes_selenio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Selênio é 34.')
    return informacoes 
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Selênio pertence ao grupo 16 da tabela periódica, conhecido 
como o grupo dos calcogênios ou grupo do oxigênio. 
Outros elementos deste grupo incluem o oxigênio, enxofre e telúrio.
''')
    return informacoes 
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Selênio é aproximadamente 78.96 u.')
    return informacoes 
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Selênio é um elemento químico não metálico que pode 
ser encontrado em várias formas, incluindo sólidos, líquidos
e gases, dependendo das condições. É um elemento essencial para a vida,
pois é necessário em pequenas quantidades na dieta humana. 
''')
    return informacoes 
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = (''' 
1s²
2s² 2p⁶
3s² 3p⁶ 3d¹⁰
4s² 4p⁴
''')
    return informacoes 
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O nome "selênio" deriva da palavra grega "selene," que significa "lua".
O nome foi dado devido à semelhança da luz refletida pelo elemento com
a luz da lua. O selênio foi descoberto por Jöns Jacob Berzelius em 1817. 
''')
    return informacoes 
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Selênio está localizado no 4º período da tabela periódica, 
o que significa que ele tem 4 níveis de energia em sua 
configuração eletrônica.
''')
    return informacoes 

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes