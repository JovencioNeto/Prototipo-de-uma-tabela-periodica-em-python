def informacoes_silicio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do silício é 14.')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('O Silício pertence ao grupo 14, ou família 4A da tabela periódica.')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('O Silício possui 28,0855 u de massa.')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Silício é um sólido duro, de cor cinza escuro, apresentando um certo brilho metálico.
Sua estrutura cristalina é semelhante à do diamante e suas reações químicas são 
semelhantes às do carbono. Na natureza, o silício só ocorre combinado. É encontrado
em praticamente todas as rochas, areias, barros e solos.
''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶
3s² 3p²
''')
    return informacoes
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('Silício, de silex ou silicis, que quer dizer “pedra dura”.')
    return informacoes
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Silício localiza-se no grupo 14 e período 3 da Tabela Periódica.
Isso significa que ele possui 3 níveis de enegia na sua configuração
eletrônica.''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes