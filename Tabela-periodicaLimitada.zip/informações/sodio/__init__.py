def informacoes_sodio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Sódio é 11.')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Sódio pertence à família 1A e por isso se classifica como metal alcalino na
Tabela Periódica.
  ''')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('O Sódio possui 22,989769 u de massa .')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Sódio é um metal mole, brilhante, prateado, menos denso que água, 
podendo entrar em combustão espontânea quando em contato com esta.
Não ocorre no estado nativo, mas forma 2,6% da crosta terrestre,
sendo o mais abundante dos metais alcalinos.
''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶
3s¹
''')
    return informacoes
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O Sódio metálico foi isolado pela primeira vez em 1807, em Londres, Inglaterra,
pelo químico inglês Sir Humphrey Davy (1778-1829), por eletrólise do hidróxido de sódio.
O nome sódio deriva do latim natrium e do inglês soda.
  ''')
    return informacoes
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Sódio localiza-se no grupo 1 e período 3 da Tabela Periódica.
Isso significa que ele possui 3 níveis de energia na sua
configuração eletrônica.
''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes