def informacoes_talio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Tálio é 81.')
    return informacoes

  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Tálio pertence à família dos metais representativos e está localizado
no grupo 13 da tabela periódica dos elementos. O grupo 13 é frequentemente
chamado de grupo do boro, e inclui elementos como boro (B), alumínio (Al),
gálio (Ga), índio (In), tálio (Tl) e nihônio (Nh).
  ''')
    return informacoes

  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Tálio é aproximadamente 204.383 u.')
    return informacoes

  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Tálio é altamente tóxico, por isso era usado como produto para matar
ratos e insetos. Há indícios de que cause câncer em seres humanos. Atualmente
é usado em detectores de radiação infravermelha, radiação gama, e em medicina 
nuclear. É encontrado e obtido a partir do mineral pirita e, também, é obtido
como subproduto de minérios de chumbo e zinco.
  ''')
    return informacoes

  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹⁰ 4f¹⁴
5s² 5p⁶ 5d¹⁰
6s² 6p¹
  ''')
    return informacoes

  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O Tálio é um elemento químico metálico e tem o símbolo Tl e o número atômico 81.
Foi descoberto em 1861 por Sir William Crookes. O nome "tálio" foi proposto pelo
químico croata e austríaco Ludwig Wilhelm Gilbert, que sugeriu esse nome em
homenagem à palavra grega "thallos" devido à propriedade de alguns compostos
de tálio de parecerem verdes.
''')
    return informacoes

  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Tálio está localizado no 6º período da tabela periódica dos elementos.
Isso significa que o tálio tem 6 níveis de energia ou camadas eletrônicas 
ao redor do núcleo atômico.
  ''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes

