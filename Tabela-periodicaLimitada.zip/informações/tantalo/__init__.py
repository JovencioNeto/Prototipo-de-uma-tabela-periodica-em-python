def informacoes_tantalo(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Tântalo é 73.')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Tântalo é um elemento químico com o símbolo Ta e 
número atômico 73 na tabela periódica. Ele pertence 
ao grupo 5 da tabela periódica, também conhecido 
como o grupo do nióbio, e faz parte da família 
dos metais de transição. 
''')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Tântalo é aproximadamente 180,948.')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Tântalo é um metal cinzento, denso, dúctil, muito duro,
resistente a corrosão por ácidos e um bom condutor de calor
e eletricidade. Em temperaturas abaixo de 150 °C o Tântalo
é quase completamente imune ao ataque químico, mesmo pela
agressiva água régia. Somente é atacado pelo ácido 
fluorídrico, ácido que contem o íon fluoreto ou 
mediante fusão alcalina.
''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹⁰ 4f¹⁴
5s² 5p⁶ 5d³
6s²
''')
    return informacoes
    
  elif  pesquisa == 'origem do nome' or pesquisa == '7':
    informacoes = ('''
O nome "Tântalo" tem origens mitológicas. Tântalo é uma
referência a Tântalo, um personagem da mitologia grega.
De acordo com a mitologia, Tântalo era um rei da Frígia
que foi condenado a um castigo eterno no Hades por suas
ações imprudentes. Uma das histórias mais conhecidas 
envolvendo Tântalo é a do "Tântalo faminto". 
''')
    return informacoes
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Tântalo é um elemento químico que pertence ao 6º período da tabela periódica.
Isso significa que ele possui 6 níveis de energia na sua configuração eletrônica.
''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes
