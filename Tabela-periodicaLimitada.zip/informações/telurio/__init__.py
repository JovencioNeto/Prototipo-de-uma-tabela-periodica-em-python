def informacoes_telurio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Telúrio é 52')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Telúrio pertence ao grupo 16 da tabela periódica,
também conhecido como o grupo dos calcogênios ou anfígenos.
''')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Telúrio é aproximadamente 127.60 u.')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Telúrio é um elemento metalóide que possui várias formas alotrópicas,
incluindo uma forma amorfa que é semelhante a um sólido quebradiço e com aparência 
de vidro. É usado em aplicações eletrônicas e na produção de ligas com propriedades
específicas. 
''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹⁰
5s² 5p⁴
''')
    return informacoes
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O nome "Telúrio" deriva do termo latino "tellus," que significa "terra" ou "chão",
uma vez que o Telúrio é frequentemente encontrado na forma de minerais na 
crosta terrestre. 
''')
    return informacoes
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Telúrio está localizado no 5º período da tabela periódica, 
o que significa que ele tem 5 níveis de energia em sua 
configuração eletrônica.
''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes