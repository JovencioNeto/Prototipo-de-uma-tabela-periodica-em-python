def informacoes_terbio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Térbio é 65.')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Térbio faz parte do grupo de elementos conhecido como lantanídeos,
que é uma parte da série dos elementos de transição interna.
O lantanídeo ao qual o térbio pertence é por vezes chamado de "terra rara".
''')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Térbio é aproximadamente 158.93 u.')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Térbio é um metal de transição interna que é prateado,
maleável e relativamente estável. Ele é frequentemente utilizado
em aplicações que envolvem a fabricação de ímãs de alta potência 
e dispositivos ópticos. 
''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹⁰ 4f⁹
5s² 5p⁶
6s² 
''')
    return informacoes
    
  elif  pesquisa == 'origem do nome' or pesquisa == '7':
    informacoes = ('''
O nome "Térbio" é derivado da cidade sueca de Ytterby, onde diversos minerais raros
foram encontrados, incluindo aqueles que continham o elemento.
O térbio foi isolado pela primeira vez em 1843 por Carl Gustaf Mosander.
''')
    return informacoes
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Térbio está localizado no 6º da tabela periódica,
o que significa que ele tem 6 níveis de energia em sua configuração eletrônica.
''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes
