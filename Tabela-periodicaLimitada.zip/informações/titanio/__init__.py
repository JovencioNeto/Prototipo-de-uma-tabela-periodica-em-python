def informacoes_titanio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Titânio é 22')
    return informacoes 
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('O Titânio pertence à família dos metais de transição.')
    return informacoes 
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Titânio é aproximadamente 47,867 u.')
    return informacoes 
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Titânio é um metal de transição de cor prateada, conhecido por sua 
resistência à corrosão, alta resistência e baixa densidade.
''')
    return informacoes 
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d²
4s²
''')
    return informacoes 
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O nome "Titânio" é derivado dos Titãs da mitologia grega,
que eram deuses poderosos e gigantes. 
''')
    return informacoes 
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Titânio esta localizado no 4° período da tabela periódica. Isso significa que ele 
possui 4 níveis de energia na sua configuração eletrônica.
''')
    return informacoes 
