def informacoes_torio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Tório é 90.')
    return informacoes

  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Tório (Th) é um elemento químico metálico, radioativo, tetravalente,
de cor cinzenta, pesado, mole e brilhante, que pertence ao grupo dos actínideos
e localiza-se no grupo 3 e período 7 da Tabela Periódica.
  ''')
    return informacoes

  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Tório é aproximadamente 232.03806 u.')
    return informacoes

  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Tório é um metal natural, ligeiramente radioativo. Quando puro,
o tório é um metal branco prateado que mantém o seu brilho por diversos meses.
Entretanto, em presença do ar, escurece lentamente tornando-se cinza ou, eventualmente,
preto. O óxido de tório (ThO2), também chamado de "tória", apresenta um dos pontos de
ebulição mais elevados (3300 °C) de todos os óxidos. Quando aquecido no ar, o metal de
tório inflama-se e queima produzindo uma luz branca brilhante. O tório extraído da Torita.
  ''')
    return informacoes

  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s² 
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹⁰ 4f¹⁴
5s² 5p⁶ 5d¹⁰ 5f²
6s² 6p⁶
7s²
  ''')
    return informacoes

  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O Tório foi descoberto em 1829 em Estocolmo, Suécia, pelo químico 
Jons Jacob Berzelius (1779-1848). O nome tório deriva do nome Thor
que é o deus escandinavo da guerra. Este elemento obtém-se a partir
da areia de monazite.
  ''')
    return informacoes

  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Tório (Th) é um elemento químico metálico, radioativo, tetravalente,
de cor cinzenta, pesado, mole e brilhante, que pertence ao grupo dos actínideos
e localiza-se no grupo 3 e período 7 da Tabela Periódica.
  ''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes

