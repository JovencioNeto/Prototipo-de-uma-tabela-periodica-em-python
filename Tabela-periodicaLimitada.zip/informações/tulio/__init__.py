def informacoes_tulio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Túlio é 69.')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Túlio pertence à família dos lantanídeos,
que também é conhecida como a família dos lantanoides ou terras raras.
''')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Túlio é aproximadamente 168.934 u.')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
Dentre os lantanídeos, o Túlio é um dos mais raros e, por isso,
tem alto custo e aplicações limitadas. Na sua forma metálica,
apresenta coloração acinzentada e um brilho prateado característico,
resistindo bem à corrosão. Em solução, como os demais lantanídeos, o Túlio 
adota o número de oxidação igual a +3. 
''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = (''' 
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹⁰ 4f¹³
5s² 5p⁶
6s² 
''')
    return informacoes
    
  elif  pesquisa == 'origem do nome' or pesquisa == '7':
    informacoes = ('''
O nome "Túlio" deriva do latim "Thule", uma referência poética à Escandinávia ou a 
uma terra distante no norte. O nome foi escolhido porque o Túlio foi descoberto por
cientistas suecos e finlandeses em minerais provenientes de Escandinávia.
A descoberta do Túlio ocorreu em 1879, quando os químicos Per Teodor Cleve (sueco)
e Lars Fredrik Nilson (sueco) isolaram o elemento separadamente. 
Portanto, o nome "Túlio" foi escolhido em homenagem à conexão nórdica 
da descoberta e sua origem geográfica. 
''')
    return informacoes
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Túlio está localizado no 6º período da tabela periódica.
Isso significa que ele tem 6 níveis de energia em sua 
estrutura eletrônica.
''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes