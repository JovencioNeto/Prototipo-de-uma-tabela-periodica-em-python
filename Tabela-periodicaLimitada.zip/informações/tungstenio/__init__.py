def informacoes_tungstenio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Tungstênio é 74.')
    return informacoes 
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
A família do Tungstênio está localizada no grupo 6 da tabela periódica,
que também é chamado de grupo do crômio. Portanto, a classificação da
família do tungstênio é o Grupo 6 da tabela periódica.
''')
    return informacoes 
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Tungstênio é aproximadamente 183,84 u.')
    return informacoes 
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Tungstênio é o único metal da terceira série de 
transição que se sabe ocorrer em biomoléculas, usadas
por algumas espécies de bactérias. É o elemento mais pesado
que se sabe ser usado por seres vivos. Porém, o tungstênio 
interfere com os metabolismos do molibdênio e do cobre, e 
é algo tóxico para a vida animal.
''')
    return informacoes 
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹⁰ 4f¹⁴
5s² 5p⁶ 5d⁴
6s²
''')
    return informacoes 
    
  elif  pesquisa == 'origem do nome' or pesquisa == '7':
    informacoes = ('''
O nome "tungstênio" tem origem nas palavras suecas "tung sten",
que significam "pedra pesada". O nome foi dado a este elemento
químico devido à sua alta densidade. O tungstênio é um dos elementos
mais densos da tabela periódica, com uma densidade de cerca de 19,3 
gramas por centímetro cúbico, o que o torna extremamente pesado em 
comparação com outros elementos. Essa característica levou ao nome 
"pedra pesada" em sueco, que foi posteriormente latinizado para "tung sten",
dando origem ao nome "tungstênio" em português e em muitos outros idiomas.
''')
    return informacoes 
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Tungstênio (símbolo W, número atômico 74) pertence ao 6º período da tabela periódica.
Isso significa que ele possui 6 niveis de energia na sua configuração eletrônica.
''')
    return informacoes 
    
  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes