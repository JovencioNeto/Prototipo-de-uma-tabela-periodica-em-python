def informacoes_uranio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Urânio é 92.')
    return informacoes

  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Urânio (U) é um elemento químico metálico, tri, tetra e hexavalente,
de brilho prateado, pesado, maleável, dúctil, perde o brilho ao ar,
pertence ao grupo dos actínideos e localiza-se no grupo 3 e período 7 da Tabela Periódica.
  ''')
    return informacoes

  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa Urânio é aproximadamente 238 u.')
    return informacoes

  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
"O Urânio tem grande importância para a geração de energia, pois sua propriedade
radioativa faz com que ele gere grandes quantidades energéticas durante os processos
de fissão nuclear que ocorrem nas usinas. "
  ''')
    return informacoes

  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s² 
2s² 2p⁶ 
3s² 3p⁶ 3d¹⁰
4s² 4p⁶ 4d¹⁰ 4f¹⁴
5s² 5p⁶ 5d¹⁰ 5f⁴
6s² 6p⁶
7s²
  ''')
    return informacoes

  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
O Urânio é um elemento bastante comum na Terra, incorporado ao planeta durante a sua
formação. No entanto, ele foi identificado em 1789 por Martin Heinrich Klaproth,
que deu a ele este nome em homenagem à descoberta do planeta Urano.
  ''')
    return informacoes

  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Urânio (U) é um elemento químico metálico, tri, tetra e hexavalente, de brilho
prateado, pesado, maleável, dúctil, perde o brilho ao ar, pertence ao grupo dos 
actínideos e localiza-se no grupo 3 e período 7 da Tabela Periódica.
  ''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes

