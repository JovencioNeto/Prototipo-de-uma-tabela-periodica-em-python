def informacoes_vanadio(pesquisa):
  if pesquisa == 'número atômico' or pesquisa == 'numero atomico' or pesquisa == 'número atomico' or pesquisa == 'numero atômico' or pesquisa == '1':
    informacoes = ('O número atômico do Vanádio é 23.')
    return informacoes
    
  elif pesquisa == 'familia' or pesquisa == 'família' or pesquisa == '2':
    informacoes = ('''
O Vanádio pertence aos Metais, Metais de transição, Metais pesados tóxicos,
Elementos do 4º período, Elementos do Grupo 5.
''')
    return informacoes
    
  elif pesquisa == 'peso' or pesquisa == '3':
    informacoes = ('A massa do Vanádio é aproximadamente  50,9415 u.')
    return informacoes
    
  elif pesquisa == 'descrição' or pesquisa == '4':
    informacoes = ('''
O Vanádio é um metal que não ocorre livre na natureza, mas combinado 
com outros elementos, como oxigênio, sódio, enxofre e cloreto.
Existem cerca de 65 minerais diferentes contendo vanádio. O metal também
é encontrado em rochas fosfáticas e determinados minérios, carvão e petróleo bruto.
''')
    return informacoes
    
  elif pesquisa == 'distribuição eletrônica' or pesquisa == 'distribuição eletronica' or pesquisa == '5':
    informacoes = ('''
1s²
2s² 2p⁶ 
3s² 3p⁶ 3d³
4s²
''')
    return informacoes
    
  elif pesquisa == 'origem do nome' or pesquisa == '6':
    informacoes = ('''
Sua descoberta data do começo do século XIX e seu nome faz
referência à deusa da beleza escandinava Vanadis.
''')
    return informacoes
    
  elif pesquisa == 'periodo' or pesquisa == 'período' or pesquisa == '7':
    informacoes = ('''
O Vanádio localiza-se no grupo 5 e período 4 da Tabela Periódica.
Isso significa que ele possui 4 níveis de energia na sua configuração eletrônica.
''')
    return informacoes

  else:
    informacoes = ('Sinto muito, mas não reconheço essa pesquisa!')
    return informacoes